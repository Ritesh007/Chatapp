"""
Unit test case for accessFiles.py Library.
"""

import unittest
from accessFiles import AccessFiles

# TODO write a successful testcase
class AccessFilestest(unittest.TestCase):

    @staticmethod
    def store_texts_test():
        AccessFiles.store_texts("\n This is a test line ---> ignore this \n")
        store_file=open("../Chatapp/Chat_consoleapp/files/chat.txt","r")
        for i in store_file:
            if i == "This is a test line ---> ignore this":
              assert i,"This is a test line ---> ignore this"
              break
            return False

def main():
  AccessFilestest.store_texts_test()

main()